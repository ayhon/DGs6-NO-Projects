%Maps any angle to the equivalent between -pi and pi
function a=modAngle(a)
a=mod(a+pi,2*pi)-pi;
